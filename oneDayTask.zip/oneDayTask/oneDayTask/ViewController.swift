//
//  ViewController.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var filterBtn: UIButton!
    @IBOutlet weak var propertyImg: UIImageView!
    @IBOutlet weak var titleOne: UILabel!
    @IBOutlet weak var reviewRatings: UIButton!
    @IBOutlet weak var timinsLbl: UILabel!
    @IBOutlet weak var menuLbl: UILabel!
    @IBOutlet weak var propertyDetail: UIImageView!
    @IBOutlet weak var detailsLbl: UILabel!
    @IBOutlet weak var subContent: UILabel!
    @IBOutlet weak var subTitle: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var customize: UIButton!
    @IBOutlet weak var totalAmmount: UILabel!
    @IBOutlet weak var bookMarkImg: UIImageView!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        reviewRatings.layer.cornerRadius = 16.0
        reviewRatings.layer.backgroundColor = UIColor.systemCyan.cgColor
        
        customize.layer.borderWidth = 1.0
        customize.layer.cornerRadius = 16.0
        customize.layer.borderColor = UIColor.systemCyan.cgColor
    }


    @IBAction func customizedBtn(_ sender: Any) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "customizedVC") as? customizedVC
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    
    
}


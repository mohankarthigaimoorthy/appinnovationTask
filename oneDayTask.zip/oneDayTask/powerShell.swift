//
//  powerShell.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 28/11/23.
//

import UIKit

class powerShell: UIViewController {
    
    @IBOutlet weak var bgView: UIView!
    
    @IBOutlet weak var topic: UILabel!
    
    
    @IBOutlet weak var cancel: UIButton!
    
    @IBOutlet weak var subtopic: UILabel!
    
    
    @IBOutlet weak var customized: UIButton!
    
    @IBOutlet weak var repet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        customized.layer.cornerRadius = 16.0
        customized.layer.backgroundColor = UIColor.systemCyan.cgColor
        
        
        repet.layer.cornerRadius = 16.0
        repet.layer.backgroundColor = UIColor.systemCyan.cgColor
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func customizedBtn(_ sender: Any) {
    }
 
    
    @IBAction func repeatedBtn(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

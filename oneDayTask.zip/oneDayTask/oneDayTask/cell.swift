//
//  cell.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class cell: UITableViewCell {

    
    @IBOutlet weak var radioBtn: UIButton!
   
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var totalLbl: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

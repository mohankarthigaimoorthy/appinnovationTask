//
//  bedroom.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class bedroom: UITableViewCell {

    
    @IBOutlet weak var topicLbl: UILabel!
    
    
    @IBOutlet weak var choose: UILabel!
    
    
    @IBOutlet weak var bedroomTable: UITableView!
    
    var text = ["i dont want any bathroom cleaning", "with mattress qty vaccuming no of ", "with mistress wet shampooing no the bedroom"]
    
    var tense = ["","159","199"]
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setupTable()
        
        bedroomTable.register(UINib(nibName: "cellone", bundle: nil), forCellReuseIdentifier: "cellone")
    }

    func setupTable()  {
        bedroomTable.delegate = self
        bedroomTable.dataSource = self
        DispatchQueue.main.async{
            self.bedroomTable.reloadData()
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension bedroom : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return text.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = bedroomTable.dequeueReusableCell(withIdentifier: "cellone", for: indexPath) as! cellone
        let drum = text[indexPath.row]
        let drill = tense[indexPath.row]
        cell.descrription.text = drum
        cell.ammountLbl.text = drill
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

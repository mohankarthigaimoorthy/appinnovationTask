//
//  sizeCell.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class sizeCell: UITableViewCell {

    
    @IBOutlet weak var titleLbl: UILabel!
 
    @IBOutlet weak var chooseLbl: UILabel!
    
    
    @IBOutlet weak var detail: UITableView!
    
    var call = ["1BHK", "2BHK","3BHK", "4BHK", "+4BKH"]
    var  king = ["1999","2999","3999","4999","5999"]
    
    var selectedIndexPath: IndexPath?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setupTable()
        
        detail.register(UINib(nibName: "cell", bundle: nil), forCellReuseIdentifier: "cell")
    }

    
    func setupTable() {
        detail.delegate = self
        detail.dataSource = self
        DispatchQueue.main.async {
            self.detail.reloadData()
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   
    
}


extension sizeCell : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return call.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = detail.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! cell
        let dragon = call[indexPath.row]
        let blade = king[indexPath.row]
        cell.titleLbl.text = dragon
        cell.totalLbl.text = blade
        
        print("\(cell.totalLbl.text)")
        print("\(cell.titleLbl.text)")
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           selectedIndexPath = indexPath
           tableView.reloadData()

           // Notify the parent view controller about the selection
           NotificationCenter.default.post(name: NSNotification.Name(rawValue: "SizeCellSelected"), object: nil)
       }
    
    func updateKingValues(forSelectedIndex selectedIndex: Int) {
            if selectedIndex < king.count {
                king = ["1999", "2999", "3999", "4999", "5999"]  // Update this array based on your logic
                detail.reloadData()
            }
        }
    
}

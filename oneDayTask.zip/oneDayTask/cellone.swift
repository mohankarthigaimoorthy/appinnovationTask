//
//  cellone.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class cellone: UITableViewCell {

    
    @IBOutlet weak var checkBox: UIButton!

    
    @IBOutlet weak var descrription: UILabel!
    
    
    @IBOutlet weak var minus: UIButton!
    
    @IBOutlet weak var countLbl: UILabel!
    
    @IBOutlet weak var plus: UIButton!
    
    
    @IBOutlet weak var ammountLbl: UILabel!
    
    var currentvalue = 0 {
        didSet {
            countLbl.text = "\(currentvalue)"
        }
    }
    
    var currentValue = 100{
        didSet {
            countLbl.text = "\(currentValue)"
        }
    }
    
    var iselected = false {
        didSet {
            updatchecboximage()
            updateamount()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        countLbl.text = "0"
    }
    private func updateValue(increment: Int) {
           let newValue = currentvalue + increment

           // Ensure the new value is within the desired range (0 to 100)
           if newValue >= 0 && newValue <= 100 {
               currentvalue = newValue
           }
       }
    
    private func updatchecboximage() {
        let image = iselected ? "radiobuttonon" : "radiobuttonoff"
        let images = UIImage(named: image)
        checkBox.setImage(images, for: .normal)
    }
    
    private func updateamount() {
        let ammount = currentvalue * 159
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func subTract(_ sender: Any) {
        updateValue(increment: -1)

    }
    
    @IBAction func pLus(_ sender: Any) {
        updateValue(increment: 1)

    }
    
    
    @IBAction func checbutTapped(_ sender: Any) {
   iselected = !iselected
    }
    
    
}

//
//  customizedVC.swift
//  oneDayTask
//
//  Created by Ajeeth Kumar on 27/11/23.
//

import UIKit

class customizedVC: UIViewController {

    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var buildingImg: UIImageView!
    
    
    @IBOutlet weak var bgOne: UIView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var propertiesDetails: UITableView!
    
    @IBOutlet weak var bottomView: UIView!
    
    
    @IBOutlet weak var cartView: UIView!
    
    
    @IBOutlet weak var cancelBtn: UIButton!
    
    
    @IBOutlet weak var totalCount: UILabel!
    
    @IBOutlet weak var addbtn: UIButton!
    
   
    @IBOutlet weak var addcartBtn: UIButton!
    
    var selectedSizeIndex: Int?

    
    var currentvalue = 0 {
        didSet {
            totalCount.text = "\(currentvalue)"
        }
    }
    
    var currentValue = 100{
        didSet {
            totalCount.text = "\(currentValue)"
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        cartView.layer.cornerRadius = 16.0
        cartView.layer.borderWidth = 2.0
        cartView.layer.borderColor = UIColor.systemCyan.cgColor
        
        totalCount.layer.borderColor = UIColor.systemCyan.cgColor
        totalCount.layer.borderWidth = 1.0
        
        
        addcartBtn.layer.backgroundColor = UIColor.systemCyan.cgColor
        addcartBtn.layer.cornerRadius = 16.0
        
        tablesetup()
        
        propertiesDetails.register(UINib(nibName: "sizeCell", bundle: nil), forCellReuseIdentifier: "sizeCell")
        propertiesDetails.register(UINib(nibName: "bedroom", bundle: nil), forCellReuseIdentifier: "bedroom")
        
        totalCount.text = "0"
//        totalCount.text =  "100"
      
        NotificationCenter.default.addObserver(self, selector: #selector(sizeCellSelected), name: NSNotification.Name(rawValue: "SizeCellSelected"), object: nil)

    }
    
    @objc func sizeCellSelected() {
           if let sizeCell = propertiesDetails.visibleCells.first as? sizeCell {
               sizeCell.updateKingValues(forSelectedIndex: 1)
               updateAddCartButtonTitle()
           }
       }

    func updateAddCartButtonTitle() {
            guard let sizeCell = propertiesDetails.visibleCells.first as? sizeCell else {
                return
            }

            if let selectedIndexPath = sizeCell.selectedIndexPath,
               selectedIndexPath.row < sizeCell.king.count {
                let selectedKingValue = sizeCell.king[selectedIndexPath.row]
                addcartBtn.setTitle("Add to Cart - \(selectedKingValue)", for: .normal)
            }
        }

    private func updateValue(increment: Int) {
           let newValue = currentvalue + increment

           if newValue >= 0 && newValue <= 100 {
               currentvalue = newValue
           }
       }

    func tablesetup() {
        propertiesDetails.delegate = self
        propertiesDetails.dataSource = self
        DispatchQueue.main.async {
            self.propertiesDetails.reloadData()
        }
    }
    
    @objc func increase() {
//        if currentvalue < 100 {
//            currentvalue += 1
//        }
        updateValue(increment: 1)

    }
    @objc func decrease() {
//        increase()
//        if currentValue > 0 {
//                    currentValue -= 1
//                }
        updateValue(increment: -1)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func subtracBtn(_ sender: Any) {
        decrease()
    }
    
    @IBAction func addBtn(_ sender: Any) {
        increase()
    }
    
    
    
    @IBAction func addCart(_ sender: Any) {
        
        let vp = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "powerShell") as? powerShell
        self.navigationController?.pushViewController(vp!, animated: true)
        
//        let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "powerShell") as? powerShell
print("))))")
    }
    
}

extension customizedVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = propertiesDetails.dequeueReusableCell(withIdentifier: "sizeCell", for: indexPath) as! sizeCell
            cell.detail.reloadData()
            return cell
        }
        else if indexPath.row == 1 {
            let dell = propertiesDetails.dequeueReusableCell(withIdentifier: "bedroom", for: indexPath) as! bedroom
            dell.bedroomTable.reloadData()
            return dell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    
    
}
